package nonViolations;

public class FilePersistence implements InvoicePersistence {

	@Override
	public void save(Invoice invoice) {
		// Save to file
	
		System.out.println("Saving in File....");
	}

}
