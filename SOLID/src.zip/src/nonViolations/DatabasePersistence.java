package nonViolations;

public class DatabasePersistence implements InvoicePersistence{

	@Override
	public void save(Invoice invoice) {
		// Save to DB
		
		System.out.println("Saving in Database....");
		
	}

}
