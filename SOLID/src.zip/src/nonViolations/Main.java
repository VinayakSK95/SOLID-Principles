package nonViolations;

public class Main {

	public static void main(String[] args) {
		
		Tool tool=new Tool("Hammer", 2021, 100);
		
		Invoice invoice=new Invoice(tool, 2, 5.0, 2.0);
		
		DetailsPrinter detailsPrinter=new DetailsPrinter();
		detailsPrinter.printToolDetails(tool);
		detailsPrinter.printInvoice(invoice);
		
		InvoicePersistence invoicePersistence=new DatabasePersistence();
		invoicePersistence.save(invoice);
		
		InvoicePersistence invoicePersistence2=new FilePersistence();
		invoicePersistence2.save(invoice);
		
	}
}
