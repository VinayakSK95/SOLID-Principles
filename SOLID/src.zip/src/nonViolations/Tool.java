package nonViolations;

public class Tool {

	String name;
	int year;
	int price;
	
	public Tool(String name, int year, int price) {
		super();
		this.name = name;
		this.year = year;
		this.price = price;
	}

	
}