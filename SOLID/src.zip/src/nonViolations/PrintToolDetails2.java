package nonViolations;

public class PrintToolDetails2 {

	public void printToolDetails(Tool tool)
	{
		System.out.println("Name: "+tool.name+" "+"Price: "+tool.price+" "+"Mfg Year: "+tool.year);

	}
}
