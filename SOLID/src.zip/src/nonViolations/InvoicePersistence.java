package nonViolations;

public interface InvoicePersistence {

	 public void save(Invoice invoice);
}
