package nonViolations;

public interface PrintInvoice {

	public void printInvoice(Invoice invoice);
}
