package nonViolations;

public interface PrintToolDetails {

	public void printToolDetails(Tool tool);
}
