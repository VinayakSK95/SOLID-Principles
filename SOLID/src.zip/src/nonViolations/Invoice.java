package nonViolations;

public class Invoice {
	private Tool tool;
	private int quantity;
	private double discountRate;
	private double taxRate;
	private double total;

	public Invoice(Tool tool, int quantity, double discountRate, double taxRate) {
		this.tool = tool;
		this.quantity = quantity;
		this.discountRate = discountRate;
		this.taxRate = taxRate;
		this.total = this.calculateTotal();
	}

	public double calculateTotal() {
	    double price = ((tool.price - tool.price * discountRate) * this.quantity);

		total = price * (1 + taxRate);

		return total;
	}
	
	
	
	
	

	public Tool getTool() {
		return tool;
	}

	public void setTool(Tool tool) {
		this.tool = tool;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	public double getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(double taxRate) {
		this.taxRate = taxRate;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
	
}