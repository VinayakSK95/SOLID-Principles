package nonViolations;

public class DetailsPrinter extends PrintToolDetails2 implements PrintInvoice {

	
	public void printToolDetails(Tool tool) {
		System.out.println("Name: "+tool.name+" "+"Price: "+tool.price+" "+"Mfg Year: "+tool.year);
	}

	@Override
	public void printInvoice(Invoice invoice) {
		System.out.println(invoice.getQuantity() + "x " + invoice.getTool().name + " " + invoice.getTool().price + " $");
		System.out.println("Discount Rate: " + invoice.getDiscountRate());
		System.out.println("Tax Rate: " + invoice.getTaxRate());
		System.out.println("Total: " + invoice.getTotal() + " $");
	}
}
