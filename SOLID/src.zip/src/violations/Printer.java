package violations;

public interface Printer {

	
	public void printInvoice();
	
	public void printToolDetails();
}
